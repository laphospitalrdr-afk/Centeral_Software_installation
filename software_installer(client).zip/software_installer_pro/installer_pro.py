import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import requests
import threading
import os
import subprocess
import json
import time
from datetime import datetime

# =============== LOGIN DIALOG ===============

class LoginDialog:
    """Login dialog for server credentials"""
    def __init__(self, parent, config):
        self.result = None
        self.config = config

        self.dialog = tk.Toplevel(parent)
        self.dialog.title("Connect to Server")
        self.dialog.geometry("450x380")
        self.dialog.resizable(False, False)
        self.dialog.transient(parent)
        self.dialog.grab_set()

        # Center
        self.dialog.update_idletasks()
        x = (self.dialog.winfo_screenwidth() // 2) - (450 // 2)
        y = (self.dialog.winfo_screenheight() // 2) - (380 // 2)
        self.dialog.geometry(f"+{x}+{y}")

        self.create_ui()

    def create_ui(self):
        # Header
        header = tk.Frame(self.dialog, bg='#0078D4', height=80)
        header.pack(fill=tk.X)
        header.pack_propagate(False)

        tk.Label(header, text="🔐", font=('Segoe UI', 32),
                bg='#0078D4', fg='white').pack(pady=5)

        tk.Label(header, text="Connect to Software Portal",
                font=('Segoe UI', 12, 'bold'),
                bg='#0078D4', fg='white').pack()

        # Form
        form_frame = tk.Frame(self.dialog, bg='white')
        form_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=20)

        # Server URL
        tk.Label(form_frame, text="Server URL", font=('Segoe UI', 10, 'bold'),
                bg='white', fg='#333', anchor='w').pack(fill=tk.X, pady=(5, 3))

        self.server_entry = tk.Entry(form_frame, font=('Segoe UI', 11),
                                     bg='#F5F5F5', relief=tk.FLAT, bd=0)
        self.server_entry.pack(fill=tk.X, ipady=8, pady=(0, 3))
        self.server_entry.insert(0, self.config.get('server_url', 'http://192.168.1.100:5000'))

        tk.Label(form_frame, text="Example: http://192.168.1.100:5000 or http://localhost:5000",
                font=('Segoe UI', 8), bg='white', fg='#666',
                anchor='w').pack(fill=tk.X)

        # Username
        tk.Label(form_frame, text="Username", font=('Segoe UI', 10, 'bold'),
                bg='white', fg='#333', anchor='w').pack(fill=tk.X, pady=(12, 3))

        self.username_entry = tk.Entry(form_frame, font=('Segoe UI', 11),
                                       bg='#F5F5F5', relief=tk.FLAT, bd=0)
        self.username_entry.pack(fill=tk.X, ipady=8, pady=(0, 3))
        self.username_entry.insert(0, self.config.get('username', 'client'))

        tk.Label(form_frame, text="Default: client or admin",
                font=('Segoe UI', 8), bg='white', fg='#666',
                anchor='w').pack(fill=tk.X)

        # Password
        tk.Label(form_frame, text="Password", font=('Segoe UI', 10, 'bold'),
                bg='white', fg='#333', anchor='w').pack(fill=tk.X, pady=(12, 3))

        self.password_entry = tk.Entry(form_frame, font=('Segoe UI', 11),
                                       bg='#F5F5F5', relief=tk.FLAT, bd=0,
                                       show='●')
        self.password_entry.pack(fill=tk.X, ipady=8)
        self.password_entry.insert(0, self.config.get('password', 'client123'))

        # Buttons
        button_frame = tk.Frame(form_frame, bg='white')
        button_frame.pack(fill=tk.X, pady=(20, 0))

        tk.Button(button_frame, text="Cancel", font=('Segoe UI', 10),
                 bg='#E1E1E1', fg='#333', relief=tk.FLAT,
                 width=12, pady=10, cursor='hand2',
                 command=self.cancel).pack(side=tk.LEFT, padx=(0, 10))

        tk.Button(button_frame, text="Connect", font=('Segoe UI', 10, 'bold'),
                 bg='#0078D4', fg='white', relief=tk.FLAT,
                 width=12, pady=10, cursor='hand2',
                 command=self.connect).pack(side=tk.LEFT)

        self.dialog.bind('<Return>', lambda e: self.connect())
        self.server_entry.focus()

    def connect(self):
        server = self.server_entry.get().strip()
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()

        if not server or server == 'http://':
            messagebox.showerror("Error", "Please enter server URL\n\nExample: http://192.168.1.100:5000",
                               parent=self.dialog)
            self.server_entry.focus()
            return

        if not username:
            messagebox.showerror("Error", "Please enter username", parent=self.dialog)
            self.username_entry.focus()
            return

        if not password:
            messagebox.showerror("Error", "Please enter password", parent=self.dialog)
            self.password_entry.focus()
            return

        if not server.startswith('http://') and not server.startswith('https://'):
            server = 'http://' + server

        self.result = {
            'server_url': server,
            'username': username,
            'password': password
        }
        self.dialog.destroy()

    def cancel(self):
        self.result = None
        self.dialog.destroy()

    def show(self):
        self.dialog.wait_window()
        return self.result

# =============== MAIN APPLICATION ===============

class SoftwareCard(tk.Frame):
    """Software card widget"""
    def __init__(self, parent, software, on_toggle, **kwargs):
        super().__init__(parent, bg='white', relief=tk.RAISED, bd=1, **kwargs)
        self.software = software
        self.on_toggle = on_toggle
        self.selected = False

        # Icon
        icon_frame = tk.Frame(self, bg='#F0F0F0', width=60, height=60)
        icon_frame.pack(side=tk.LEFT, padx=10, pady=10)
        icon_frame.pack_propagate(False)

        letter = software.get('name', 'S')[0].upper()
        colors = ['#0078D4', '#107C10', '#D83B01', '#8764B8', '#00188F']
        color = colors[hash(letter) % len(colors)]

        icon_label = tk.Label(icon_frame, text=letter, bg=color, fg='white',
                             font=('Segoe UI', 24, 'bold'))
        icon_label.place(relx=0.5, rely=0.5, anchor='center')

        # Info
        info_frame = tk.Frame(self, bg='white')
        info_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=10)

        name_label = tk.Label(info_frame, text=software.get('name', 'Unknown'),
                             font=('Segoe UI', 11, 'bold'), bg='white', anchor='w')
        name_label.pack(fill=tk.X)

        version = software.get('version', 'N/A')
        size = software.get('size_mb', '0')
        details_label = tk.Label(info_frame, text=f"Version: {version}",
                                font=('Segoe UI', 9), bg='white', fg='#666', anchor='w')
        details_label.pack(fill=tk.X)

        size_label = tk.Label(info_frame, text=f"{size} MB", font=('Segoe UI', 9),
                             bg='white', fg='#666', anchor='w')
        size_label.pack(fill=tk.X)

        category = software.get('category', '')
        if category:
            cat_label = tk.Label(info_frame, text=f"Category", font=('Segoe UI', 8),
                                bg='#E1E1E1', fg='#333', padx=5, pady=2)
            cat_label.pack(anchor='w', pady=(5, 0))

        # Toggle
        self.toggle_var = tk.BooleanVar(value=False)
        self.toggle_btn = ttk.Checkbutton(self, variable=self.toggle_var,
                                          command=self._on_toggle_click,
                                          style='Switch.TCheckbutton')
        self.toggle_btn.pack(side=tk.RIGHT, padx=15)

        self.bind('<Button-1>', lambda e: self.toggle())
        for child in self.winfo_children():
            if child != self.toggle_btn:
                child.bind('<Button-1>', lambda e: self.toggle())

    def toggle(self):
        self.selected = not self.selected
        self.toggle_var.set(self.selected)
        self.config(bg='#E6F3FF' if self.selected else 'white')
        for child in self.winfo_children():
            if hasattr(child, 'config') and child != self.toggle_btn:
                try:
                    child.config(bg='#E6F3FF' if self.selected else 'white')
                except:
                    pass
        self.on_toggle(self.software, self.selected)

    def _on_toggle_click(self):
        self.selected = self.toggle_var.get()
        self.config(bg='#E6F3FF' if self.selected else 'white')
        for child in self.winfo_children():
            if hasattr(child, 'config') and child != self.toggle_btn:
                try:
                    child.config(bg='#E6F3FF' if self.selected else 'white')
                except:
                    pass
        self.on_toggle(self.software, self.selected)

class SoftwareInstallerPro:
    def __init__(self, root):
        self.root = root
        self.root.title("Software Installer Pro")
        self.root.geometry("1200x750")
        self.root.minsize(900, 600)

        self.config_file = "config/config.json"
        self.load_config()

        self.categories = []
        self.software_list = []
        self.selected_software = {}
        self.download_path = os.path.join(os.getcwd(), "downloads")
        os.makedirs(self.download_path, exist_ok=True)

        self.session = None
        self.install_queue = []
        self.installing = False

        self.setup_styles()
        self.create_ui()

        # Show login dialog on startup
        self.root.after(100, self.show_login_dialog)

    def load_config(self):
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    self.server_url = config.get('server_url', '')
                    self.username = config.get('username', '')
                    self.password = config.get('password', '')
            else:
                self.server_url = ''
                self.username = ''
                self.password = ''
        except:
            self.server_url = ''
            self.username = ''
            self.password = ''

    def save_config(self):
        try:
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            config = {
                'server_url': self.server_url,
                'username': self.username,
                'password': self.password
            }
            with open(self.config_file, 'w') as f:
                json.dump(config, f)
        except Exception as e:
            self.log(f"Error saving config: {e}")

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('TFrame', background='#F5F5F5')
        style.configure('Switch.TCheckbutton', background='white', font=('Segoe UI', 10))

    def create_ui(self):
        main_container = tk.Frame(self.root, bg='#F5F5F5')
        main_container.pack(fill=tk.BOTH, expand=True)

        self.create_top_bar(main_container)
        self.create_info_banner(main_container)

        content = tk.Frame(main_container, bg='#F5F5F5')
        content.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.create_sidebar(content)
        self.create_main_area(content)
        self.create_right_panel(content)

    def create_top_bar(self, parent):
        top_bar = tk.Frame(parent, bg='white', height=60)
        top_bar.pack(fill=tk.X)
        top_bar.pack_propagate(False)

        logo_frame = tk.Frame(top_bar, bg='#0078D4', width=50, height=50)
        logo_frame.pack(side=tk.LEFT, padx=5, pady=5)
        logo_frame.pack_propagate(False)

        tk.Label(logo_frame, text="S", font=('Segoe UI', 20, 'bold'),
                bg='#0078D4', fg='white').place(relx=0.5, rely=0.5, anchor='center')

        tk.Label(top_bar, text="Software Installer Pro", font=('Segoe UI', 14, 'bold'),
                bg='white', fg='#333').pack(side=tk.LEFT, padx=10)

        status_frame = tk.Frame(top_bar, bg='white')
        status_frame.pack(side=tk.RIGHT, padx=10)

        self.status_indicator = tk.Canvas(status_frame, width=12, height=12,
                                         bg='white', highlightthickness=0)
        self.status_indicator.pack(side=tk.LEFT, padx=5)
        self.status_dot = self.status_indicator.create_oval(2, 2, 10, 10, fill='#E74C3C', outline='')

        self.status_label = tk.Label(status_frame, text="Disconnected",
                                     font=('Segoe UI', 9), bg='white', fg='#666')
        self.status_label.pack(side=tk.LEFT, padx=5)

        self.user_label = tk.Label(status_frame, text="👤 Not Connected",
                                   font=('Segoe UI', 9), bg='white', fg='#333')
        self.user_label.pack(side=tk.LEFT, padx=10)

        settings_label = tk.Label(status_frame, text="⚙", font=('Segoe UI', 16),
                                 bg='white', fg='#666', cursor='hand2')
        settings_label.pack(side=tk.LEFT, padx=5)
        settings_label.bind('<Button-1>', lambda e: self.show_login_dialog())

    def create_info_banner(self, parent):
        self.banner = tk.Frame(parent, bg='#D4E6F1', height=40)
        self.banner.pack(fill=tk.X)
        self.banner.pack_propagate(False)

        tk.Label(self.banner, text="ℹ", font=('Segoe UI', 14),
                bg='#D4E6F1', fg='#0078D4').pack(side=tk.LEFT, padx=10)

        self.banner_label = tk.Label(self.banner,
                                     text="Click the settings icon (⚙) to enter your server details and connect.",
                                     font=('Segoe UI', 9), bg='#D4E6F1', fg='#333')
        self.banner_label.pack(side=tk.LEFT, pady=10)

    def create_sidebar(self, parent):
        sidebar = tk.Frame(parent, bg='white', width=200)
        sidebar.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        sidebar.pack_propagate(False)

        tk.Label(sidebar, text="Categories", font=('Segoe UI', 12, 'bold'),
                bg='white', fg='#333', anchor='w').pack(fill=tk.X, padx=15, pady=(15, 10))

        all_btn = tk.Frame(sidebar, bg='#0078D4', height=40)
        all_btn.pack(fill=tk.X, padx=10, pady=2)
        all_btn.pack_propagate(False)

        tk.Label(all_btn, text="🏠 All Software", font=('Segoe UI', 10),
                bg='#0078D4', fg='white', anchor='w').pack(fill=tk.BOTH, padx=15)
        all_btn.bind('<Button-1>', lambda e: self.show_all_software())

        self.category_frame = tk.Frame(sidebar, bg='white')
        self.category_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        download_btn = tk.Frame(sidebar, bg='white', height=50)
        download_btn.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=10)
        download_btn.pack_propagate(False)

        tk.Button(download_btn, text="⬇ Download Category ZIP",
                 font=('Segoe UI', 9), bg='#0078D4', fg='white',
                 relief=tk.FLAT, cursor='hand2',
                 command=self.download_category).pack(fill=tk.BOTH)

    def create_main_area(self, parent):
        main_area = tk.Frame(parent, bg='#F5F5F5')
        main_area.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        action_bar = tk.Frame(main_area, bg='#F5F5F5', height=60)
        action_bar.pack(fill=tk.X, pady=(0, 10))
        action_bar.pack_propagate(False)

        search_frame = tk.Frame(action_bar, bg='white', relief=tk.FLAT, bd=1)
        search_frame.pack(side=tk.LEFT, fill=tk.Y, expand=True, padx=(0, 10))

        tk.Label(search_frame, text="🔍", font=('Segoe UI', 12),
                bg='white').pack(side=tk.LEFT, padx=10)

        self.search_entry = tk.Entry(search_frame, font=('Segoe UI', 10),
                                     bg='white', relief=tk.FLAT, bd=0)
        self.search_entry.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        self.search_entry.insert(0, "Search")
        self.search_entry.bind('<FocusIn>', lambda e: self.search_entry.delete(0, tk.END) if self.search_entry.get() == "Search" else None)
        self.search_entry.bind('<KeyRelease>', self.filter_software)

        btn_frame = tk.Frame(action_bar, bg='#F5F5F5')
        btn_frame.pack(side=tk.LEFT)

        tk.Button(btn_frame, text="Select All", font=('Segoe UI', 9),
                 bg='#E1E1E1', fg='#333', relief=tk.FLAT, padx=15, pady=10,
                 cursor='hand2', command=self.select_all).pack(side=tk.LEFT, padx=2)

        tk.Button(btn_frame, text="Clear Selection", font=('Segoe UI', 9),
                 bg='#E1E1E1', fg='#333', relief=tk.FLAT, padx=15, pady=10,
                 cursor='hand2', command=self.clear_selection).pack(side=tk.LEFT, padx=2)

        tk.Button(btn_frame, text="▶ Start Installation", font=('Segoe UI', 10, 'bold'),
                 bg='#0078D4', fg='white', relief=tk.FLAT, padx=20, pady=10,
                 cursor='hand2', command=self.start_installation).pack(side=tk.LEFT, padx=2)

        grid_container = tk.Frame(main_area, bg='#F5F5F5')
        grid_container.pack(fill=tk.BOTH, expand=True)

        scrollbar = tk.Scrollbar(grid_container)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.software_canvas = tk.Canvas(grid_container, bg='#F5F5F5',
                                        highlightthickness=0,
                                        yscrollcommand=scrollbar.set)
        self.software_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.software_canvas.yview)

        self.software_grid = tk.Frame(self.software_canvas, bg='#F5F5F5')
        self.canvas_window = self.software_canvas.create_window((0, 0),
                                                                window=self.software_grid,
                                                                anchor='nw')

        self.software_grid.bind('<Configure>', lambda e: self.software_canvas.configure(scrollregion=self.software_canvas.bbox('all')))
        self.software_canvas.bind('<Configure>', lambda e: self.software_canvas.itemconfig(self.canvas_window, width=e.width))
        self.software_canvas.bind_all("<MouseWheel>", lambda e: self.software_canvas.yview_scroll(int(-1*(e.delta/120)), "units"))

    def create_right_panel(self, parent):
        right_panel = tk.Frame(parent, bg='#F5F5F5', width=320)
        right_panel.pack(side=tk.RIGHT, fill=tk.Y, padx=(10, 0))
        right_panel.pack_propagate(False)

        queue_container = tk.Frame(right_panel, bg='white', relief=tk.RAISED, bd=1)
        queue_container.pack(fill=tk.BOTH, expand=False, pady=(0, 10))

        queue_header = tk.Frame(queue_container, bg='white')
        queue_header.pack(fill=tk.X, padx=15, pady=10)

        tk.Label(queue_header, text="Installation Queue", font=('Segoe UI', 11, 'bold'),
                bg='white', fg='#333').pack(side=tk.LEFT)

        self.queue_frame = tk.Frame(queue_container, bg='white')
        self.queue_frame.pack(fill=tk.BOTH, padx=10, pady=(0, 10))

        tk.Button(queue_container, text="Clear Queue", font=('Segoe UI', 9),
                 bg='#E74C3C', fg='white', relief=tk.FLAT, pady=8,
                 cursor='hand2', command=self.clear_queue).pack(fill=tk.X, padx=10, pady=(0, 10))

        log_container = tk.Frame(right_panel, bg='white', relief=tk.RAISED, bd=1)
        log_container.pack(fill=tk.BOTH, expand=True)

        log_header = tk.Frame(log_container, bg='white')
        log_header.pack(fill=tk.X, padx=15, pady=10)

        tk.Label(log_header, text="Activity Log", font=('Segoe UI', 11, 'bold'),
                bg='white', fg='#333').pack(side=tk.LEFT)

        self.log_text = scrolledtext.ScrolledText(log_container,
                                                  font=('Consolas', 9),
                                                  bg='#2C3E50', fg='#2ECC71',
                                                  relief=tk.FLAT, bd=0,
                                                  state=tk.DISABLED, wrap=tk.WORD)
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))

        self.log("✓ Application ready")
        self.log("⚙ Click settings icon to connect to server")

    def log(self, message):
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.config(state=tk.NORMAL)
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.log_text.see(tk.END)
        self.log_text.config(state=tk.DISABLED)

    def show_login_dialog(self):
        """Show login dialog"""
        config = {
            'server_url': self.server_url,
            'username': self.username,
            'password': self.password
        }

        dialog = LoginDialog(self.root, config)
        result = dialog.show()

        if result:
            self.server_url = result['server_url']
            self.username = result['username']
            self.password = result['password']
            self.connect_to_server()

    def update_status(self, connected):
        if connected:
            self.status_indicator.itemconfig(self.status_dot, fill='#27AE60')
            self.status_label.config(text="Connected")
            self.user_label.config(text=f"👤 {self.username}")
        else:
            self.status_indicator.itemconfig(self.status_dot, fill='#E74C3C')
            self.status_label.config(text="Disconnected")
            self.user_label.config(text="👤 Not Connected")

    def connect_to_server(self):
        self.log(f"Connecting to {self.server_url}...")
        threading.Thread(target=self._connect_thread, daemon=True).start()

    def _connect_thread(self):
        try:
            self.session = requests.Session()
            response = self.session.post(f"{self.server_url}/login",
                                        data={'username': self.username, 'password': self.password},
                                        timeout=10)

            if response.status_code == 200:
                self.save_config()
                self.root.after(0, self._on_connected)
            else:
                self.root.after(0, lambda: self._on_error("Login failed - Invalid credentials"))
        except Exception as e:
            self.root.after(0, lambda: self._on_error(f"Connection failed: {e}"))

    def _on_connected(self):
        self.update_status(True)
        self.log("✓ Connected successfully")
        self.banner_label.config(text="Connected! Browse categories or search for software to install.")
        self.load_categories()

    def _on_error(self, msg):
        self.update_status(False)
        self.log(f"✗ {msg}")
        messagebox.showerror("Connection Error", msg)

    def load_categories(self):
        threading.Thread(target=self._load_categories_thread, daemon=True).start()

    def _load_categories_thread(self):
        try:
            response = self.session.get(f"{self.server_url}/api/categories", timeout=10)
            if response.status_code == 200:
                self.categories = response.json()
                self.root.after(0, self._populate_categories)
                return
        except:
            pass

        try:
            response = self.session.get(f"{self.server_url}/", timeout=10)
            if response.status_code == 200:
                import re
                ids = list(set(re.findall(r'/category/(\d+)', response.text)))
                names = re.findall(r'<h5 class="card-title">.*?<i.*?></i>\s*([^<]+)</h5>',
                                 response.text, re.DOTALL)

                self.categories = []
                for i, cid in enumerate(ids):
                    if i < len(names):
                        self.categories.append({'id': int(cid), 'name': names[i].strip()})

                self.root.after(0, self._populate_categories)
        except Exception as e:
            self.root.after(0, lambda: self.log(f"Error: {e}"))

    def _populate_categories(self):
        for widget in self.category_frame.winfo_children():
            widget.destroy()

        for cat in self.categories:
            cat_btn = tk.Frame(self.category_frame, bg='white', height=35, cursor='hand2')
            cat_btn.pack(fill=tk.X, pady=2)
            cat_btn.pack_propagate(False)

            label = tk.Label(cat_btn, text=f"📁 {cat['name']}", font=('Segoe UI', 9),
                           bg='white', fg='#333', anchor='w')
            label.pack(fill=tk.BOTH, padx=10)

            cat_btn.bind('<Button-1>', lambda e, c=cat: self.load_software(c['id']))
            label.bind('<Button-1>', lambda e, c=cat: self.load_software(c['id']))

            cat_btn.bind('<Enter>', lambda e, b=cat_btn, l=label: (b.config(bg='#F0F0F0'), l.config(bg='#F0F0F0')))
            cat_btn.bind('<Leave>', lambda e, b=cat_btn, l=label: (b.config(bg='white'), l.config(bg='white')))

        self.log(f"✓ Loaded {len(self.categories)} categories")

    def show_all_software(self):
        self.log("Loading all software...")
        threading.Thread(target=self._load_all_software_thread, daemon=True).start()

    def _load_all_software_thread(self):
        try:
            response = self.session.get(f"{self.server_url}/api/software", timeout=10)
            if response.status_code == 200:
                self.software_list = response.json()
                self.root.after(0, self._populate_software_grid)
        except Exception as e:
            self.root.after(0, lambda: self.log(f"Error: {e}"))

    def load_software(self, cat_id):
        self.log(f"Loading category software...")
        threading.Thread(target=self._load_software_thread, args=(cat_id,), daemon=True).start()

    def _load_software_thread(self, cat_id):
        try:
            response = self.session.get(f"{self.server_url}/api/category/{cat_id}/software", timeout=10)
            if response.status_code == 200:
                data = response.json()
                self.software_list = data['software']
                for s in self.software_list:
                    s['category'] = data['category']['name']
                self.root.after(0, self._populate_software_grid)
                return
        except:
            pass

        try:
            response = self.session.get(f"{self.server_url}/category/{cat_id}", timeout=10)
            if response.status_code == 200:
                import re
                names = re.findall(r'<h5 class="card-title">([^<]+)</h5>', response.text)
                versions = re.findall(r'<strong>Version:</strong>\s*([^<\n]+)', response.text)
                sizes = re.findall(r'<strong>Size:</strong>\s*([\d.]+)\s*MB', response.text)
                ids = re.findall(r'/download/(\d+)', response.text)

                cat_name = next((c['name'] for c in self.categories if c['id'] == cat_id), 'Unknown')

                self.software_list = []
                for i, sid in enumerate(ids):
                    self.software_list.append({
                        'id': int(sid),
                        'name': names[i].strip() if i < len(names) else 'Unknown',
                        'version': versions[i].strip() if i < len(versions) else 'N/A',
                        'size_mb': sizes[i] if i < len(sizes) else '0',
                        'category': cat_name
                    })

                self.root.after(0, self._populate_software_grid)
        except Exception as e:
            self.root.after(0, lambda: self.log(f"Error: {e}"))

    def _populate_software_grid(self):
        for widget in self.software_grid.winfo_children():
            widget.destroy()

        self.selected_software = {}

        row = 0
        col = 0
        max_cols = 3

        for software in self.software_list:
            card = SoftwareCard(self.software_grid, software, self.on_software_toggle)
            card.grid(row=row, column=col, padx=5, pady=5, sticky='ew')

            col += 1
            if col >= max_cols:
                col = 0
                row += 1

        for i in range(max_cols):
            self.software_grid.columnconfigure(i, weight=1, minsize=200)

        self.log(f"✓ Loaded {len(self.software_list)} software")

    def on_software_toggle(self, software, selected):
        if selected:
            self.selected_software[software['id']] = software
            self.log(f"+ Selected: {software['name']}")
        else:
            if software['id'] in self.selected_software:
                del self.selected_software[software['id']]
                self.log(f"- Deselected: {software['name']}")

        count = len(self.selected_software)
        if count > 0:
            self.banner_label.config(text=f"{count} software selected. Click 'Start Installation' to begin.")
        else:
            self.banner_label.config(text="Select software to install or browse categories.")

    def select_all(self):
        for widget in self.software_grid.winfo_children():
            if isinstance(widget, SoftwareCard) and not widget.selected:
                widget.toggle()

    def clear_selection(self):
        for widget in self.software_grid.winfo_children():
            if isinstance(widget, SoftwareCard) and widget.selected:
                widget.toggle()

    def filter_software(self, event=None):
        query = self.search_entry.get().lower()
        if query == "search":
            return

        for widget in self.software_grid.winfo_children():
            if isinstance(widget, SoftwareCard):
                name = widget.software.get('name', '').lower()
                if query in name:
                    widget.grid()
                else:
                    widget.grid_remove()

    def start_installation(self):
        if not self.selected_software:
            messagebox.showwarning("No Selection", "Please select software to install")
            return

        self.install_queue = list(self.selected_software.values())
        self.update_queue_display()

        msg = f"Install {len(self.install_queue)} software sequentially?\n\n"
        msg += "Each installer will open with full UI.\n"
        msg += "Complete each installation before next starts.\n\n"
        msg += "Ready?"

        if messagebox.askyesno("Start Installation", msg):
            self.log(f"\n{'='*40}")
            self.log(f"🚀 Starting queue: {len(self.install_queue)} items")
            self.log(f"{'='*40}")
            threading.Thread(target=self._process_install_queue, daemon=True).start()

    def update_queue_display(self):
        for widget in self.queue_frame.winfo_children():
            widget.destroy()

        for i, soft in enumerate(self.install_queue):
            item_frame = tk.Frame(self.queue_frame, bg='#F0F0F0', height=40)
            item_frame.pack(fill=tk.X, pady=2)
            item_frame.pack_propagate(False)

            tk.Label(item_frame, text=f"{i+1}.", font=('Segoe UI', 9, 'bold'),
                    bg='#F0F0F0', fg='#0078D4').pack(side=tk.LEFT, padx=10)

            tk.Label(item_frame, text=soft['name'], font=('Segoe UI', 9),
                    bg='#F0F0F0', fg='#333', anchor='w').pack(side=tk.LEFT, fill=tk.X, expand=True)

    def clear_queue(self):
        if not self.installing:
            self.install_queue = []
            self.update_queue_display()
            self.log("Queue cleared")
        else:
            messagebox.showwarning("Busy", "Cannot clear during installation")

    def _process_install_queue(self):
        self.installing = True
        total = len(self.install_queue)

        for i, soft in enumerate(self.install_queue.copy()):
            num = i + 1

            try:
                self.root.after(0, lambda: self.log(f"\n[{num}/{total}] {soft['name']}"))
                self.root.after(0, lambda: self.log(f"  ⬇ Downloading..."))

                url = f"{self.server_url}/download/{soft['id']}"
                response = self.session.get(url, stream=True, timeout=300)

                if response.status_code != 200:
                    self.root.after(0, lambda: self.log(f"  ✗ Download failed"))
                    continue

                filename = soft['name']
                if 'content-disposition' in response.headers:
                    import re
                    cd = response.headers['content-disposition']
                    match = re.findall('filename="?([^"]+)"?', cd)
                    if match:
                        filename = match[0]

                if not any(filename.lower().endswith(e) for e in ['.exe', '.msi', '.zip']):
                    filename += '.exe'

                filepath = os.path.join(self.download_path, filename)

                with open(filepath, 'wb') as f:
                    for chunk in response.iter_content(8192):
                        f.write(chunk)

                self.root.after(0, lambda: self.log(f"  ✓ Downloaded"))
                self.root.after(0, lambda: self.log(f"  🚀 Launching installer..."))
                self.root.after(0, lambda: self.log(f"  ⏳ Waiting for completion..."))

                if filepath.lower().endswith('.exe'):
                    process = subprocess.Popen([filepath], shell=True)
                    process.wait()
                elif filepath.lower().endswith('.msi'):
                    process = subprocess.Popen(['msiexec', '/i', filepath], shell=True)
                    process.wait()
                else:
                    os.startfile(filepath)
                    time.sleep(3)

                self.root.after(0, lambda: self.log(f"  ✓ Completed"))

                if soft in self.install_queue:
                    self.install_queue.remove(soft)
                    self.root.after(0, self.update_queue_display)

                if num < total:
                    time.sleep(2)

            except Exception as e:
                self.root.after(0, lambda err=e: self.log(f"  ✗ Error: {err}"))

        self.installing = False
        self.root.after(0, lambda: self.log(f"\n{'='*40}"))
        self.root.after(0, lambda: self.log(f"✓ All installations completed!"))
        self.root.after(0, lambda: self.log(f"{'='*40}\n"))
        self.root.after(0, lambda: messagebox.showinfo("Complete",
                                   f"Successfully completed {total} installations!"))

    def download_category(self):
        messagebox.showinfo("Coming Soon", "Category download feature")

if __name__ == "__main__":
    root = tk.Tk()
    app = SoftwareInstallerPro(root)
    root.mainloop()
